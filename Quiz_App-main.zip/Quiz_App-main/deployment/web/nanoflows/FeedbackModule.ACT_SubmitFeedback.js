import { addEnumerations, t } from "mendix";
import { SUB_Feedback_ResetLocalStorage } from "./FeedbackModule.SUB_Feedback_ResetLocalStorage.js";

export const ACT_SubmitFeedback = {
  "name": "FeedbackModule.ACT_SubmitFeedback",
  "instructions": [
    {
      "type": "microflowCall",
      "label": "96456fb3-25dd-4d5b-9c09-f5eb553b0afc",
      "operationId": "/q89zuWgqluB2sJ4hLwMYg",
      "parameters": [
        {
          "name": "Feedback",
          "value": {
            "type": "variable",
            "variable": "Feedback"
          },
          "kind": "object"
        }
      ],
      "outputVar": "isValid"
    },
    {
      "type": "switch",
      "label": "5ea6bb9f-7611-4a12-b738-3b19f0c52db0",
      "condition": {
        "type": "variable",
        "variable": "isValid"
      },
      "targets": {
        "true": "e248a069-2282-4af0-b44e-1815357a5678",
        "false": "10b2a700-d654-4ab5-b896-2c19c961c69b"
      }
    },
    {
      "type": "return",
      "label": "10b2a700-d654-4ab5-b896-2c19c961c69b",
      "result": {
        "type": "literal",
        "value": null
      },
      "resultKind": "primitive"
    },
    {
      "type": "microflowCall",
      "label": "e248a069-2282-4af0-b44e-1815357a5678",
      "operationId": "uAk42l75WF2S3cRWGk/dpg",
      "parameters": [
        {
          "name": "Feedback",
          "value": {
            "type": "variable",
            "variable": "Feedback"
          },
          "kind": "object"
        }
      ],
      "outputVar": "ResponseHelper"
    },
    {
      "type": "closeForm",
      "label": "c157453d-6fba-4f50-86dd-6bcd410139f3",
      "numberOfPagesToClose": {
        "type": "literalNumeric",
        "value": "1"
      }
    },
    {
      "type": "switch",
      "label": "a5ae719e-79fd-4349-8297-94df69a160e6",
      "condition": {
        "type": "function",
        "name": "!=",
        "parameters": [
          {
            "type": "variable",
            "variable": "ResponseHelper"
          },
          {
            "type": "literal",
            "value": null
          }
        ]
      },
      "targets": {
        "true": "61b722ed-3e5d-44a6-a989-f6dc03600c44",
        "false": "4d4d592d-f12f-4ff2-8cab-1228ff2168ad"
      }
    },
    {
      "type": "jump",
      "label": "4d4d592d-f12f-4ff2-8cab-1228ff2168ad",
      "target": "e20d9b1e-b831-4d35-8c09-1649eab735de"
    },
    {
      "type": "openForm",
      "label": "e20d9b1e-b831-4d35-8c09-1649eab735de",
      "path": "FeedbackModule/PopupFailure.page.xml",
      "params": {
        "name": "FeedbackModule/PopupFailure.page.xml",
        "location": "modal",
        "resizable": false
      }
    },
    {
      "type": "return",
      "label": "1faf8041-ca36-4c44-9794-7f718929d82a",
      "result": {
        "type": "literal",
        "value": null
      },
      "resultKind": "primitive"
    },
    {
      "type": "openForm",
      "label": "61b722ed-3e5d-44a6-a989-f6dc03600c44",
      "path": "FeedbackModule/PopupSuccess.page.xml",
      "params": {
        "name": "FeedbackModule/PopupSuccess.page.xml",
        "location": "modal",
        "resizable": false
      },
      "inputArgs": {
        "$Response": {
          "type": "variable",
          "variable": "ResponseHelper"
        }
      }
    },
    {
      "type": "nanoflowCall",
      "label": "5a17c729-0911-473d-9a3a-710d0b62a382",
      "flow": () => SUB_Feedback_ResetLocalStorage,
      "parameters": [
        {
          "name": "Feedback",
          "value": {
            "type": "variable",
            "variable": "Feedback"
          },
          "kind": "object"
        }
      ]
    },
    {
      "type": "return",
      "label": "1c8c0869-81d9-440a-aa7c-176785a98030",
      "result": {
        "type": "literal",
        "value": null
      },
      "resultKind": "primitive"
    }
  ]
};
