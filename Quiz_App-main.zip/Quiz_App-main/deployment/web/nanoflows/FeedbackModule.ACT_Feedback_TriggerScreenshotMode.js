import { addEnumerations, t } from "mendix";

export const ACT_Feedback_TriggerScreenshotMode = {
  "name": "FeedbackModule.ACT_Feedback_TriggerScreenshotMode",
  "instructions": [
    {
      "type": "closeForm",
      "label": "0add2923-0f98-450d-934c-17ec25df148e"
    },
    {
      "type": "javaScriptActionCall",
      "label": "1e672491-911c-48ce-8c8a-0bef189356ef",
      "action": () => require("D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/javascriptsource/feedbackmodule/actions/JS_ToggleFeedbackScreenshotWidget").JS_ToggleFeedbackScreenshotWidget,
      "outputVar": "base64FromWidget",
      "parameters": []
    },
    {
      "type": "switch",
      "label": "996802ce-74b5-4bcf-9061-ff4099a76998",
      "condition": {
        "type": "function",
        "name": "!=",
        "parameters": [
          {
            "type": "variable",
            "variable": "base64FromWidget"
          },
          {
            "type": "literal",
            "value": "uploadCancelled"
          }
        ]
      },
      "targets": {
        "true": "2f5149a7-1b37-450f-bcd4-f4931dd2dc73",
        "false": "90f7c6d1-587a-4317-83bd-4899e10fb35c"
      }
    },
    {
      "type": "jump",
      "label": "90f7c6d1-587a-4317-83bd-4899e10fb35c",
      "target": "6cfe2825-2e16-4efa-9fab-a0f4e1b1fa59"
    },
    {
      "type": "jump",
      "label": "6cfe2825-2e16-4efa-9fab-a0f4e1b1fa59",
      "target": "0265dc23-5e62-4687-bace-36a00f374b22"
    },
    {
      "type": "jump",
      "label": "0265dc23-5e62-4687-bace-36a00f374b22",
      "target": "f2a5a0ec-4fbc-4ed0-86c6-40d98c84afb9"
    },
    {
      "type": "openForm",
      "label": "f2a5a0ec-4fbc-4ed0-86c6-40d98c84afb9",
      "path": "FeedbackModule/ShareFeedback.page.xml",
      "params": {
        "name": "FeedbackModule/ShareFeedback.page.xml",
        "location": "modal",
        "resizable": true
      }
    },
    {
      "type": "return",
      "label": "36671894-8374-4198-9a64-4d671b610123",
      "result": {
        "type": "literal",
        "value": null
      },
      "resultKind": "primitive"
    },
    {
      "type": "switch",
      "label": "2f5149a7-1b37-450f-bcd4-f4931dd2dc73",
      "condition": {
        "type": "function",
        "name": "!=",
        "parameters": [
          {
            "type": "variable",
            "variable": "base64FromWidget"
          },
          {
            "type": "literal",
            "value": null
          }
        ]
      },
      "targets": {
        "true": "661231a2-ea64-4ede-b9a8-8c86b6ddb83e",
        "false": "c2a60c1c-a26f-4bc4-9b09-28c94a2a39cb"
      }
    },
    {
      "type": "return",
      "label": "c2a60c1c-a26f-4bc4-9b09-28c94a2a39cb",
      "result": {
        "type": "literal",
        "value": null
      },
      "resultKind": "primitive"
    },
    {
      "type": "javaScriptActionCall",
      "label": "661231a2-ea64-4ede-b9a8-8c86b6ddb83e",
      "action": () => require("D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/javascriptsource/feedbackmodule/actions/JS_isStrictMode").JS_isStrictMode,
      "outputVar": "isStrictMode",
      "parameters": []
    },
    {
      "type": "switch",
      "label": "1267318a-2663-45d6-b22f-55e6c89cfbef",
      "condition": {
        "type": "function",
        "name": "=",
        "parameters": [
          {
            "type": "variable",
            "variable": "isStrictMode"
          },
          {
            "type": "literal",
            "value": false
          }
        ]
      },
      "targets": {
        "true": "6e5f6ef5-93f8-4519-a653-bcc597b4ce2c",
        "false": "406d59c1-4128-4ec9-9f5f-b27b1e4fd33b"
      }
    },
    {
      "type": "jump",
      "label": "406d59c1-4128-4ec9-9f5f-b27b1e4fd33b",
      "target": "d70856f4-1a2a-4a04-8a55-66865694c82f"
    },
    {
      "type": "javaScriptActionCall",
      "label": "d70856f4-1a2a-4a04-8a55-66865694c82f",
      "action": () => require("D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/javascriptsource/feedbackmodule/actions/JS_SetSingleLocalStorageObjectItem").JS_SetSingleLocalStorageObjectItem,
      "parameters": [
        {
          "kind": "primitive",
          "value": {
            "type": "constant",
            "name": "FeedbackModule.LocalStorageKey"
          }
        },
        {
          "kind": "primitive",
          "value": {
            "type": "variable",
            "variable": "base64FromWidget"
          }
        }
      ]
    },
    {
      "type": "jump",
      "label": "506197ab-c587-4087-9d12-b5024676f39b",
      "target": "0265dc23-5e62-4687-bace-36a00f374b22"
    },
    {
      "type": "jump",
      "label": "0265dc23-5e62-4687-bace-36a00f374b22",
      "target": "f2a5a0ec-4fbc-4ed0-86c6-40d98c84afb9"
    },
    {
      "type": "changeObject",
      "label": "6e5f6ef5-93f8-4519-a653-bcc597b4ce2c",
      "inputVar": "Feedback",
      "member": "ImageB64",
      "value": {
        "type": "variable",
        "variable": "base64FromWidget"
      }
    },
    {
      "type": "commitObjects",
      "operationId": "WhtmpA9DhVi/+Xy4c0XAng",
      "inputVar": "Feedback"
    },
    {
      "type": "jump",
      "label": "0265dc23-5e62-4687-bace-36a00f374b22",
      "target": "f2a5a0ec-4fbc-4ed0-86c6-40d98c84afb9"
    }
  ]
};
