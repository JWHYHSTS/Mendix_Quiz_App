import { addEnumerations, t } from "mendix";
import { Get_And_Set_Feedback_NPE } from "./FeedbackModule.Get_And_Set_Feedback_NPE.js";

export const SUB_Feedback_GetOrCreate = {
  "name": "FeedbackModule.SUB_Feedback_GetOrCreate",
  "instructions": [
    {
      "type": "javaScriptActionCall",
      "label": "1c7821f1-90a9-4d9e-8017-c954c6413bc8",
      "action": () => require("D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/javascriptsource/feedbackmodule/actions/JS_isStrictMode").JS_isStrictMode,
      "outputVar": "isStrictMode",
      "parameters": []
    },
    {
      "type": "switch",
      "label": "367207e2-b8e5-4b05-8cc8-b70eded4808a",
      "condition": {
        "type": "function",
        "name": "=",
        "parameters": [
          {
            "type": "variable",
            "variable": "isStrictMode"
          },
          {
            "type": "literal",
            "value": false
          }
        ]
      },
      "targets": {
        "false": "edf06cde-c40a-4c01-b487-aadf992d85eb",
        "true": "3575fc72-aaa6-4444-87bc-a8632761e2f2"
      }
    },
    {
      "type": "tryCatch",
      "label": "3575fc72-aaa6-4444-87bc-a8632761e2f2",
      "catchTarget": "3ee37d2b-c2cc-45a1-8885-1bb4ff3a3867",
      "body": [
        {
          "type": "javaScriptActionCall",
          "action": () => require("D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/javascriptsource/feedbackmodule/actions/JS_GetFeedbackStorageObject").JS_GetFeedbackStorageObject,
          "outputVar": "LocalFeedback",
          "parameters": [
            {
              "kind": "primitive",
              "value": {
                "type": "constant",
                "name": "FeedbackModule.LocalStorageKey"
              }
            },
            {
              "kind": "primitive",
              "value": {
                "type": "literal",
                "value": "FeedbackModule.Feedback"
              }
            }
          ]
        },
        {
          "type": "return",
          "result": {
            "type": "literal",
            "value": true
          },
          "resultKind": "primitive"
        }
      ]
    },
    {
      "type": "switch",
      "label": "3d7d6968-c8ab-4cf4-9f39-249dbe59a6b0",
      "condition": {
        "type": "function",
        "name": "!=",
        "parameters": [
          {
            "type": "variable",
            "variable": "LocalFeedback"
          },
          {
            "type": "literal",
            "value": null
          }
        ]
      },
      "targets": {
        "false": "63d8cad6-b3db-4a12-a43c-d38067661cee",
        "true": "4568b789-000a-46c3-81f2-4b653d0ca2ee"
      }
    },
    {
      "type": "return",
      "label": "4568b789-000a-46c3-81f2-4b653d0ca2ee",
      "result": {
        "type": "variable",
        "variable": "LocalFeedback"
      },
      "resultKind": "object"
    },
    {
      "type": "jump",
      "label": "63d8cad6-b3db-4a12-a43c-d38067661cee",
      "target": "847da9f4-6bd4-4e53-9a4c-ef187d861f3f"
    },
    {
      "type": "createObject",
      "label": "847da9f4-6bd4-4e53-9a4c-ef187d861f3f",
      "objectType": "FeedbackModule.Feedback",
      "outputVar": "NewFeedback"
    },
    {
      "type": "return",
      "label": "bd81f4cc-d43c-4c0f-8209-8bcf6465fc8d",
      "result": {
        "type": "variable",
        "variable": "NewFeedback"
      },
      "resultKind": "object"
    },
    {
      "type": "jump",
      "label": "3ee37d2b-c2cc-45a1-8885-1bb4ff3a3867",
      "target": "63d8cad6-b3db-4a12-a43c-d38067661cee"
    },
    {
      "type": "jump",
      "label": "63d8cad6-b3db-4a12-a43c-d38067661cee",
      "target": "847da9f4-6bd4-4e53-9a4c-ef187d861f3f"
    },
    {
      "type": "jump",
      "label": "edf06cde-c40a-4c01-b487-aadf992d85eb",
      "target": "9f4ead1c-76d9-4212-b291-b4dcdb5f9cd5"
    },
    {
      "type": "nanoflowCall",
      "label": "9f4ead1c-76d9-4212-b291-b4dcdb5f9cd5",
      "flow": () => Get_And_Set_Feedback_NPE,
      "parameters": [],
      "outputVar": "StrictModeFeedback"
    },
    {
      "type": "return",
      "label": "2d4c8c50-1a6e-4d3d-9608-cfbd7a0fe3ec",
      "result": {
        "type": "variable",
        "variable": "StrictModeFeedback"
      },
      "resultKind": "object"
    }
  ]
};
