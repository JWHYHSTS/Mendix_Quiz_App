import { createElement } from "react";
const React = { createElement };

import { PageFragment } from "mendix/PageFragment";
import { ActionProperty } from "mendix/ActionProperty";
import { AssociationObjectListProperty } from "mendix/AssociationObjectListProperty";
import { AssociationObjectProperty } from "mendix/AssociationObjectProperty";
import { AttributeProperty } from "mendix/AttributeProperty";
import { DerivedUniqueIdProperty } from "mendix/DerivedUniqueIdProperty";
import { DynamicClassProperty } from "mendix/DynamicClassProperty";
import { ExpressionProperty } from "mendix/ExpressionProperty";
import { MicroflowObjectProperty } from "mendix/MicroflowObjectProperty";
import { TemplatedWidgetProperty } from "mendix/TemplatedWidgetProperty";
import { TextProperty } from "mendix/TextProperty";
import { ValidationProperty } from "mendix/ValidationProperty";
import { WebDynamicImageProperty } from "mendix/WebDynamicImageProperty";

import { ActionButton } from "mendix/widgets/web/ActionButton";
import { CheckBox } from "mendix/widgets/web/CheckBox";
import { ConditionalVisibilityWrapper } from "mendix/widgets/web/ConditionalVisibilityWrapper";
import { DataView } from "mendix/widgets/web/DataView";
import { Div } from "mendix/widgets/web/Div";
import { FormGroup } from "mendix/widgets/web/FormGroup";
import * as ImageWidgetModule from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/deployment/web/widgets/com/mendix/widget/web/image/Image.mjs";
const Image = Object.getOwnPropertyDescriptor(ImageWidgetModule, "Image")?.value || Object.getOwnPropertyDescriptor(ImageWidgetModule, "default")?.value;   
import "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/deployment/web/widgets/com/mendix/widget/web/image/Image.css";
import { ListView } from "mendix/widgets/web/ListView";
import { Text } from "mendix/widgets/web/Text";
import { addEnumerations, asPluginWidgets, t } from "mendix";

import { content as parentContent } from "../layouts/Atlas_Core.Atlas_Default.js";

const { $Div, $DataView, $ListView, $Text, $Image, $ConditionalVisibilityWrapper, $FormGroup, $CheckBox, $ActionButton } = asPluginWidgets({ Div, DataView, ListView, Text, Image, ConditionalVisibilityWrapper, FormGroup, CheckBox, ActionButton });

const region$Main = (historyId) => (<PageFragment renderKey={historyId}>{[
    <$Div key="p.MyFirstModule.Quiz_NewEdit.layoutGrid1"
        $widgetId="p.MyFirstModule.Quiz_NewEdit.layoutGrid1"
        class={"mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid container-fluid"}
        style={undefined}
        content={[
            <$Div key="p.MyFirstModule.Quiz_NewEdit.layoutGrid1$row0"
                $widgetId="p.MyFirstModule.Quiz_NewEdit.layoutGrid1$row0"
                class={"row"}
                style={undefined}
                content={[
                    <$Div key="p.MyFirstModule.Quiz_NewEdit.layoutGrid1$row0$column0"
                        $widgetId="p.MyFirstModule.Quiz_NewEdit.layoutGrid1$row0$column0"
                        class={"col-lg col-md col"}
                        style={undefined}
                        content={[
                            <$DataView key="p.MyFirstModule.Quiz_NewEdit.dataView1"
                                $widgetId="p.MyFirstModule.Quiz_NewEdit.dataView1"
                                class={"mx-name-dataView1 form-horizontal"}
                                style={undefined}
                                tabIndex={undefined}
                                object={AssociationObjectProperty({
                                    "dataSourceId": "p.16",
                                    "scope": "$Quiz",
                                    "editable": true
                                })}
                                emptyMessage={TextProperty({
                                    "value": t([
                                        ""
                                    ])
                                })}
                                body={[
                                    <$ListView key="p.MyFirstModule.Quiz_NewEdit.listView1"
                                        $widgetId="p.MyFirstModule.Quiz_NewEdit.listView1"
                                        class={"mx-name-listView1"}
                                        style={undefined}
                                        listValue={AssociationObjectListProperty({
                                            "dataSourceId": "p.0",
                                            "entity": "MyFirstModule.Quetions",
                                            "scope": "$Quiz",
                                            "operationId": "gPyGPRbAtVWTZ7Bm4lyOiQ",
                                            "directPath": "MyFirstModule.Quiz_Quetions/MyFirstModule.Quetions"
                                        })}
                                        itemTemplate={TemplatedWidgetProperty({
                                            "dataSourceId": "p.0",
                                            "editable": true,
                                            "children": () => [
                                                <$Text key="p.MyFirstModule.Quiz_NewEdit.text1"
                                                    $widgetId="p.MyFirstModule.Quiz_NewEdit.text1"
                                                    class={"mx-name-text1"}
                                                    style={undefined}
                                                    caption={t([
                                                        ExpressionProperty({
                                                            "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "SN" }, { "type": "literal", "value": "{}" } ] }, { "type": "literal", "value": " - " } ] }, { "type": "variable", "variable": "currentObject", "path": "Question" } ] }, "args": { "currentObject": { "widget": "p.MyFirstModule.Quiz_NewEdit.listView1", "source": "object" } } }
                                                        })
                                                    ])}
                                                    renderMode={"span"} />,
                                                <$DataView key="p.MyFirstModule.Quiz_NewEdit.dataView2"
                                                    $widgetId="p.MyFirstModule.Quiz_NewEdit.dataView2"
                                                    class={"mx-name-dataView2 form-horizontal"}
                                                    style={undefined}
                                                    tabIndex={undefined}
                                                    object={AssociationObjectProperty({
                                                        "dataSourceId": "p.23",
                                                        "scope": "p.MyFirstModule.Quiz_NewEdit.listView1",
                                                        "editable": true,
                                                        "path": "MyFirstModule.ImageQuestion_Quetions/MyFirstModule.ImageQuestion",
                                                        "operationId": "bmprAmApYVyb9RgxpUPoGw"
                                                    })}
                                                    emptyMessage={TextProperty({
                                                        "value": t([
                                                            ""
                                                        ])
                                                    })}
                                                    body={[
                                                        <$Image key="p.MyFirstModule.Quiz_NewEdit.image1"
                                                            $widgetId="p.MyFirstModule.Quiz_NewEdit.image1"
                                                            datasource={"image"}
                                                            imageObject={WebDynamicImageProperty({
                                                                "scope": "p.MyFirstModule.Quiz_NewEdit.dataView2",
                                                                "showAsThumbnail": false,
                                                                "shareObject": false
                                                            })}
                                                            defaultImageDynamic={undefined}
                                                            imageUrl={t([
                                                                ExpressionProperty({
                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                })
                                                            ])}
                                                            imageIcon={undefined}
                                                            isBackgroundImage={false}
                                                            children={undefined}
                                                            onClickType={"action"}
                                                            onClick={undefined}
                                                            alternativeText={t([
                                                                ExpressionProperty({
                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                })
                                                            ])}
                                                            widthUnit={"percentage"}
                                                            width={50}
                                                            heightUnit={"auto"}
                                                            height={100}
                                                            iconSize={14}
                                                            displayAs={"fullImage"}
                                                            responsive={true}
                                                            class={"mx-name-image1"}
                                                            style={undefined}
                                                            tabIndex={undefined} />
                                                    ]}
                                                    hideFooter={false}
                                                    footer={undefined} />,
                                                <$DataView key="p.MyFirstModule.Quiz_NewEdit.dataView3"
                                                    $widgetId="p.MyFirstModule.Quiz_NewEdit.dataView3"
                                                    class={"mx-name-dataView3 form-horizontal"}
                                                    style={undefined}
                                                    tabIndex={undefined}
                                                    object={MicroflowObjectProperty({
                                                        "dataSourceId": "p.28",
                                                        "scope": "p.MyFirstModule.Quiz_NewEdit.listView1",
                                                        "editable": true,
                                                        "operationId": "r+ttKfu5pFWQO8IVpA+EDw",
                                                        "argMap": {}
                                                    })}
                                                    emptyMessage={TextProperty({
                                                        "value": t([
                                                            ""
                                                        ])
                                                    })}
                                                    body={[
                                                        <$ConditionalVisibilityWrapper key="p.MyFirstModule.Quiz_NewEdit.text2$visibility"
                                                            $widgetId="p.MyFirstModule.Quiz_NewEdit.text2$visibility"
                                                            visible={ExpressionProperty({
                                                                "expression": { "expr": { "type": "conditional", "condition": { "type": "function", "name": "!=", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "Message" }, { "type": "literal", "value": null } ] }, "then": { "type": "literal", "value": true }, "else": { "type": "function", "name": "=", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "Message" }, { "type": "literal", "value": "" } ] } }, "args": { "currentObject": { "widget": "p.MyFirstModule.Quiz_NewEdit.dataView3", "source": "object" } } }
                                                            })}
                                                            contents={[
                                                                <$Text key="p.MyFirstModule.Quiz_NewEdit.text2"
                                                                    $widgetId="p.MyFirstModule.Quiz_NewEdit.text2"
                                                                    class={DynamicClassProperty({
                                                                        "staticClasses": "mx-name-text2 text-success",
                                                                        "dynamicClasses": { "expr": { "type": "conditional", "condition": { "type": "function", "name": "=", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "Message" }, { "type": "literal", "value": "False" } ] }, "then": { "type": "literal", "value": "text-danger" }, "else": { "type": "literal", "value": "" } }, "args": { "currentObject": { "widget": "p.MyFirstModule.Quiz_NewEdit.dataView3", "source": "object" } } }
                                                                    })}
                                                                    style={undefined}
                                                                    caption={t([
                                                                        ExpressionProperty({
                                                                            "expression": { "expr": { "type": "variable", "variable": "currentObject", "path": "Message" }, "args": { "currentObject": { "widget": "p.MyFirstModule.Quiz_NewEdit.dataView3", "source": "object" } } }
                                                                        })
                                                                    ])}
                                                                    renderMode={"h4"} />
                                                            ]} />,
                                                        <$ListView key="p.MyFirstModule.Quiz_NewEdit.listView2"
                                                            $widgetId="p.MyFirstModule.Quiz_NewEdit.listView2"
                                                            class={"mx-name-listView2"}
                                                            style={undefined}
                                                            listValue={AssociationObjectListProperty({
                                                                "dataSourceId": "p.1",
                                                                "entity": "MyFirstModule.Answers",
                                                                "scope": "p.MyFirstModule.Quiz_NewEdit.listView1",
                                                                "operationId": "loDrMqVKslugxNkJl1pktw"
                                                            })}
                                                            itemTemplate={TemplatedWidgetProperty({
                                                                "dataSourceId": "p.1",
                                                                "editable": true,
                                                                "children": () => [
                                                                    <$DataView key="p.MyFirstModule.Quiz_NewEdit.dataView4"
                                                                        $widgetId="p.MyFirstModule.Quiz_NewEdit.dataView4"
                                                                        class={"mx-name-dataView4 form-vertical"}
                                                                        style={undefined}
                                                                        tabIndex={undefined}
                                                                        object={MicroflowObjectProperty({
                                                                            "dataSourceId": "p.36",
                                                                            "scope": "p.MyFirstModule.Quiz_NewEdit.listView2",
                                                                            "editable": true,
                                                                            "operationId": "tJMzmvA5n1Gv7i5GgNYVqQ",
                                                                            "argMap": { "Answers": { "widget": "p.MyFirstModule.Quiz_NewEdit.listView2", "source": "object" }, "Quetions": { "widget": "p.MyFirstModule.Quiz_NewEdit.listView1", "source": "object" }, "Quiz": { "widget": "$Quiz", "source": "object" } }
                                                                        })}
                                                                        emptyMessage={TextProperty({
                                                                            "value": t([
                                                                                ""
                                                                            ])
                                                                        })}
                                                                        body={[
                                                                            <$FormGroup key="p.MyFirstModule.Quiz_NewEdit.checkBox1$formGroup"
                                                                                $widgetId="p.MyFirstModule.Quiz_NewEdit.checkBox1$formGroup"
                                                                                class={"mx-name-checkBox1 mx-checkbox label-after"}
                                                                                style={undefined}
                                                                                control={[
                                                                                    <$CheckBox key="p.MyFirstModule.Quiz_NewEdit.checkBox1"
                                                                                        $widgetId="p.MyFirstModule.Quiz_NewEdit.checkBox1"
                                                                                        value={AttributeProperty({
                                                                                            "scope": "p.MyFirstModule.Quiz_NewEdit.dataView4",
                                                                                            "path": "",
                                                                                            "entity": "MyFirstModule.UserAnswers",
                                                                                            "attribute": "IsAnswer",
                                                                                            "onChange": { "type": "callMicroflow", "argMap": { "Quetions": { "widget": "p.MyFirstModule.Quiz_NewEdit.listView1", "source": "object" }, "Quiz": { "widget": "$Quiz", "source": "object" }, "Check_Answer": { "widget": "p.MyFirstModule.Quiz_NewEdit.dataView3", "source": "object" } }, "config": { "operationId": "zKffl7zRZ1aJ0e8iBDV2ow", "validate": "view", "allowedRoles": [ "Administrator", "User" ] }, "disabledDuringExecution": false },
                                                                                            "isList": false,
                                                                                            "isEditable": { "expr": { "type": "variable", "variable": "dataView1", "path": "IsOpen" }, "args": { "dataView1": { "widget": "$Quiz", "source": "object" } } },
                                                                                            "validation": null
                                                                                        })}
                                                                                        readOnlyStyle={"control"}
                                                                                        onEnter={undefined}
                                                                                        onLeave={undefined}
                                                                                        caption={undefined}
                                                                                        ariaLabel={t([
                                                                                            ExpressionProperty({
                                                                                                "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                            })
                                                                                        ])}
                                                                                        tabIndex={undefined}
                                                                                        id={DerivedUniqueIdProperty({
                                                                                            "widgetId": "p.MyFirstModule.Quiz_NewEdit.checkBox1"
                                                                                        })} />
                                                                                ]}
                                                                                caption={undefined}
                                                                                labelFor={DerivedUniqueIdProperty({
                                                                                    "widgetId": "p.MyFirstModule.Quiz_NewEdit.checkBox1"
                                                                                })}
                                                                                width={3}
                                                                                orientation={"vertical"}
                                                                                hasError={ValidationProperty({
                                                                                    "inputWidgetId": "p.MyFirstModule.Quiz_NewEdit.checkBox1"
                                                                                })} />,
                                                                            <$Text key="p.MyFirstModule.Quiz_NewEdit.text3"
                                                                                $widgetId="p.MyFirstModule.Quiz_NewEdit.text3"
                                                                                class={"mx-name-text3"}
                                                                                style={undefined}
                                                                                caption={t([
                                                                                    ExpressionProperty({
                                                                                        "expression": { "expr": { "type": "variable", "variable": "listView2", "path": "Answer" }, "args": { "listView2": { "widget": "p.MyFirstModule.Quiz_NewEdit.listView2", "source": "object" } } }
                                                                                    })
                                                                                ])}
                                                                                renderMode={"span"} />,
                                                                            <$Image key="p.MyFirstModule.Quiz_NewEdit.image2"
                                                                                $widgetId="p.MyFirstModule.Quiz_NewEdit.image2"
                                                                                datasource={"image"}
                                                                                imageObject={WebDynamicImageProperty({
                                                                                    "scope": "p.MyFirstModule.Quiz_NewEdit.dataView4",
                                                                                    "showAsThumbnail": false,
                                                                                    "shareObject": false,
                                                                                    "path": "MyFirstModule.UserAnswers_Answers/MyFirstModule.Answers/MyFirstModule.Answers_ImageQuestion/MyFirstModule.ImageQuestion"
                                                                                })}
                                                                                defaultImageDynamic={undefined}
                                                                                imageUrl={t([
                                                                                    ExpressionProperty({
                                                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                    })
                                                                                ])}
                                                                                imageIcon={undefined}
                                                                                isBackgroundImage={false}
                                                                                children={undefined}
                                                                                onClickType={"action"}
                                                                                onClick={undefined}
                                                                                alternativeText={t([
                                                                                    ExpressionProperty({
                                                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                    })
                                                                                ])}
                                                                                widthUnit={"percentage"}
                                                                                width={50}
                                                                                heightUnit={"auto"}
                                                                                height={100}
                                                                                iconSize={14}
                                                                                displayAs={"fullImage"}
                                                                                responsive={true}
                                                                                class={"mx-name-image2"}
                                                                                style={undefined}
                                                                                tabIndex={undefined} />
                                                                        ]}
                                                                        hideFooter={false}
                                                                        footer={undefined} />
                                                                ]
                                                            })}
                                                            onClick={undefined}
                                                            pageSize={0} />
                                                    ]}
                                                    hideFooter={false}
                                                    footer={undefined} />
                                            ]
                                        })}
                                        onClick={undefined}
                                        pageSize={0} />
                                ]}
                                hideFooter={false}
                                footer={[
                                    <$ConditionalVisibilityWrapper key="p.MyFirstModule.Quiz_NewEdit.actionButton1$visibility"
                                        $widgetId="p.MyFirstModule.Quiz_NewEdit.actionButton1$visibility"
                                        visible={ExpressionProperty({
                                            "expression": { "expr": { "type": "variable", "variable": "currentObject", "path": "IsOpen" }, "args": { "currentObject": { "widget": "p.MyFirstModule.Quiz_NewEdit.dataView1", "source": "object" } } }
                                        })}
                                        contents={[
                                            <$ActionButton key="p.MyFirstModule.Quiz_NewEdit.actionButton1"
                                                $widgetId="p.MyFirstModule.Quiz_NewEdit.actionButton1"
                                                buttonId={"p.MyFirstModule.Quiz_NewEdit.actionButton1"}
                                                class={"mx-name-actionButton1 btn-icon-right"}
                                                style={undefined}
                                                tabIndex={undefined}
                                                renderType={"button"}
                                                role={undefined}
                                                buttonClass={"btn-primary"}
                                                caption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Save as Draft" }, "args": {} }
                                                    })
                                                ])}
                                                tooltip={TextProperty({
                                                    "value": t([
                                                        ""
                                                    ])
                                                })}
                                                icon={undefined}
                                                action={ActionProperty({
                                                    "action": { "type": "saveChanges", "argMap": { "$object": { "widget": "p.MyFirstModule.Quiz_NewEdit.dataView1", "source": "object" } }, "config": { "operationId": "EfTtPar4cFu74j+8F6xwZg", "closePage": true }, "disabledDuringExecution": true },
                                                    "abortOnServerValidation": true
                                                })} />
                                        ]} />,
                                    <$ActionButton key="p.MyFirstModule.Quiz_NewEdit.actionButton2"
                                        $widgetId="p.MyFirstModule.Quiz_NewEdit.actionButton2"
                                        buttonId={"p.MyFirstModule.Quiz_NewEdit.actionButton2"}
                                        class={"mx-name-actionButton2 btn-icon-right"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-success"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Close" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "closePage", "argMap": {}, "config": {}, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />,
                                    <$ConditionalVisibilityWrapper key="p.MyFirstModule.Quiz_NewEdit.actionButton3$visibility"
                                        $widgetId="p.MyFirstModule.Quiz_NewEdit.actionButton3$visibility"
                                        visible={ExpressionProperty({
                                            "expression": { "expr": { "type": "conditional", "condition": { "type": "variable", "variable": "currentObject", "path": "IsOpen" }, "then": { "type": "function", "name": "_hasSomeRole", "parameters": [ { "type": "literal", "value": "Administrator" }, { "type": "literal", "value": "User" } ] }, "else": { "type": "literal", "value": false } }, "args": { "currentObject": { "widget": "p.MyFirstModule.Quiz_NewEdit.dataView1", "source": "object" } } }
                                        })}
                                        contents={[
                                            <$ActionButton key="p.MyFirstModule.Quiz_NewEdit.actionButton3"
                                                $widgetId="p.MyFirstModule.Quiz_NewEdit.actionButton3"
                                                buttonId={"p.MyFirstModule.Quiz_NewEdit.actionButton3"}
                                                class={"mx-name-actionButton3 btn-icon-right"}
                                                style={undefined}
                                                tabIndex={undefined}
                                                renderType={"button"}
                                                role={undefined}
                                                buttonClass={"btn-success"}
                                                caption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Finish quiz" }, "args": {} }
                                                    })
                                                ])}
                                                tooltip={TextProperty({
                                                    "value": t([
                                                        ""
                                                    ])
                                                })}
                                                icon={undefined}
                                                action={ActionProperty({
                                                    "action": { "type": "callMicroflow", "argMap": { "Quiz": { "widget": "$Quiz", "source": "object" } }, "config": { "operationId": "DEWZHQHU6Ve3onbGhV6rFg", "validate": "view", "allowedRoles": [ "Administrator", "User" ] }, "disabledDuringExecution": true },
                                                    "abortOnServerValidation": true
                                                })} />
                                        ]} />
                                ]} />
                        ]} />
                ]} />
        ]} />
]}</PageFragment>);

export const title = t([
    "Edit Quiz"
]);

export const classes = "layout-atlas layout-atlas-responsive-default";

export const autofocus = "off";
export const style = {};
export const content = { ...parentContent,
    "Atlas_Core.Atlas_Default.Main": region$Main,
};
