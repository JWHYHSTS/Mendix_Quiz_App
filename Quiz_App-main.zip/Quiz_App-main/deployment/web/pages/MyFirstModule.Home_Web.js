import { createElement } from "react";
const React = { createElement };

import { PageFragment } from "mendix/PageFragment";
import { ActionProperty } from "mendix/ActionProperty";
import { DatabaseObjectListProperty } from "mendix/DatabaseObjectListProperty";
import { ExpressionProperty } from "mendix/ExpressionProperty";
import { ListAttributeProperty } from "mendix/ListAttributeProperty";
import { ListExpressionProperty } from "mendix/ListExpressionProperty";
import { SelectionProperty } from "mendix/SelectionProperty";
import { TemplatedWidgetProperty } from "mendix/TemplatedWidgetProperty";
import { TextProperty } from "mendix/TextProperty";
import { WebIconProperty } from "mendix/WebIconProperty";

import { ActionButton } from "mendix/widgets/web/ActionButton";
import { ConditionalVisibilityWrapper } from "mendix/widgets/web/ConditionalVisibilityWrapper";
import * as DatagridWidgetModule from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/deployment/web/widgets/com/mendix/widget/web/datagrid/Datagrid.mjs";
const Datagrid = Object.getOwnPropertyDescriptor(DatagridWidgetModule, "Datagrid")?.value || Object.getOwnPropertyDescriptor(DatagridWidgetModule, "default")?.value;   
import * as DatagridDropdownFilterWidgetModule from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/deployment/web/widgets/com/mendix/widget/web/datagriddropdownfilter/DatagridDropdownFilter.mjs";
const DatagridDropdownFilter = Object.getOwnPropertyDescriptor(DatagridDropdownFilterWidgetModule, "DatagridDropdownFilter")?.value || Object.getOwnPropertyDescriptor(DatagridDropdownFilterWidgetModule, "default")?.value;   
import * as DatagridNumberFilterWidgetModule from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/deployment/web/widgets/com/mendix/widget/web/datagridnumberfilter/DatagridNumberFilter.mjs";
const DatagridNumberFilter = Object.getOwnPropertyDescriptor(DatagridNumberFilterWidgetModule, "DatagridNumberFilter")?.value || Object.getOwnPropertyDescriptor(DatagridNumberFilterWidgetModule, "default")?.value;   
import { Div } from "mendix/widgets/web/Div";
import { Text } from "mendix/widgets/web/Text";
import { addEnumerations, asPluginWidgets, t } from "mendix";

import { content as parentContent } from "../layouts/Atlas_Core.Atlas_TopBar.js";

const { $Div, $Text, $Datagrid, $DatagridNumberFilter, $DatagridDropdownFilter, $ConditionalVisibilityWrapper, $ActionButton } = asPluginWidgets({ Div, Text, Datagrid, DatagridNumberFilter, DatagridDropdownFilter, ConditionalVisibilityWrapper, ActionButton });

const region$Main = (historyId) => (<PageFragment renderKey={historyId}>{[
    <$Div key="p.MyFirstModule.Home_Web.layoutGrid3"
        $widgetId="p.MyFirstModule.Home_Web.layoutGrid3"
        class={"mx-name-layoutGrid3 mx-layoutgrid mx-layoutgrid-fixed container"}
        style={{
            "--layoutgrid-row-gap": "var(--spacing-large)"
        }}
        content={[
            <$Div key="p.MyFirstModule.Home_Web.layoutGrid3$row0"
                $widgetId="p.MyFirstModule.Home_Web.layoutGrid3$row0"
                class={"row"}
                style={undefined}
                content={[
                    <$Div key="p.MyFirstModule.Home_Web.layoutGrid3$row0$column0"
                        $widgetId="p.MyFirstModule.Home_Web.layoutGrid3$row0$column0"
                        class={"col-lg col-md col"}
                        style={undefined}
                        content={[
                            <$Text key="p.MyFirstModule.Home_Web.text2"
                                $widgetId="p.MyFirstModule.Home_Web.text2"
                                class={"mx-name-text2"}
                                style={undefined}
                                caption={t([
                                    ExpressionProperty({
                                        "expression": { "expr": { "type": "literal", "value": "Quiz" }, "args": {} }
                                    })
                                ])}
                                renderMode={"h2"} />
                        ]} />
                ]} />,
            <$Div key="p.MyFirstModule.Home_Web.layoutGrid3$row1"
                $widgetId="p.MyFirstModule.Home_Web.layoutGrid3$row1"
                class={"row"}
                style={undefined}
                content={[
                    <$Div key="p.MyFirstModule.Home_Web.layoutGrid3$row1$column0"
                        $widgetId="p.MyFirstModule.Home_Web.layoutGrid3$row1$column0"
                        class={"col-lg col-md col"}
                        style={undefined}
                        content={[
                            <$Datagrid key="p.MyFirstModule.Home_Web.dataGrid2_1"
                                $widgetId="p.MyFirstModule.Home_Web.dataGrid2_1"
                                advanced={false}
                                datasource={DatabaseObjectListProperty({
                                    "dataSourceId": "p.0",
                                    "entity": "MyFirstModule.Quiz",
                                    "operationId": "WqZU/0VibF2sOwWybSRJyw",
                                    "sort": []
                                })}
                                refreshInterval={0}
                                itemSelection={SelectionProperty({
                                    "selectionType": "Single",
                                    "dataSourceId": "p.0"
                                })}
                                itemSelectionMethod={"rowClick"}
                                itemSelectionMode={"clear"}
                                showSelectAllToggle={true}
                                keepSelection={false}
                                loadingType={"spinner"}
                                refreshIndicator={false}
                                columns={[
                                    {
                                        "showContentAs": "attribute",
                                        "attribute": ListAttributeProperty({
                                            "path": "System.owner/System.User",
                                            "entity": "System.User",
                                            "attribute": "Name",
                                            "attributeType": "String",
                                            "sortable": true,
                                            "filterable": true,
                                            "dataSourceId": "p.0",
                                            "isList": false
                                        }),
                                        "content": undefined,
                                        "dynamicText": t([
                                            undefined
                                        ]),
                                        "exportValue": t([
                                            undefined
                                        ]),
                                        "header": t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Owner" }, "args": {} }
                                            })
                                        ]),
                                        "tooltip": t([
                                            undefined
                                        ]),
                                        "filter": undefined,
                                        "visible": ExpressionProperty({
                                            "expression": { "expr": { "type": "literal", "value": true }, "args": {} }
                                        }),
                                        "sortable": true,
                                        "resizable": true,
                                        "draggable": true,
                                        "hidable": "yes",
                                        "allowEventPropagation": true,
                                        "width": "autoFill",
                                        "minWidth": "auto",
                                        "minWidthLimit": 100,
                                        "size": 1,
                                        "alignment": "left",
                                        "wrapText": false
                                    },
                                    {
                                        "showContentAs": "dynamicText",
                                        "attribute": ListAttributeProperty({
                                            "path": "",
                                            "entity": "MyFirstModule.Quiz",
                                            "attribute": "createdDate",
                                            "attributeType": "DateTime",
                                            "sortable": true,
                                            "filterable": true,
                                            "dataSourceId": "p.0",
                                            "isList": false
                                        }),
                                        "content": undefined,
                                        "dynamicText": t([
                                            ListExpressionProperty({
                                                "expression": { "expr": { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "createdDate" }, { "type": "literal", "value": "{\"type\":\"datetime\"}" } ] }, "args": { "currentObject": { "widget": "p.MyFirstModule.Home_Web.dataGrid2_1", "source": "object" } } },
                                                "dataSourceId": "p.0"
                                            })
                                        ]),
                                        "exportValue": t([
                                            undefined
                                        ]),
                                        "header": t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Created Date" }, "args": {} }
                                            })
                                        ]),
                                        "tooltip": t([
                                            undefined
                                        ]),
                                        "filter": undefined,
                                        "visible": ExpressionProperty({
                                            "expression": { "expr": { "type": "literal", "value": true }, "args": {} }
                                        }),
                                        "sortable": true,
                                        "resizable": true,
                                        "draggable": true,
                                        "hidable": "yes",
                                        "allowEventPropagation": true,
                                        "width": "autoFill",
                                        "minWidth": "auto",
                                        "minWidthLimit": 100,
                                        "size": 1,
                                        "alignment": "left",
                                        "wrapText": false
                                    },
                                    {
                                        "showContentAs": "attribute",
                                        "attribute": ListAttributeProperty({
                                            "path": "",
                                            "entity": "MyFirstModule.Quiz",
                                            "attribute": "TrueAnswers",
                                            "attributeType": "Integer",
                                            "sortable": true,
                                            "filterable": true,
                                            "dataSourceId": "p.0",
                                            "isList": false
                                        }),
                                        "content": undefined,
                                        "dynamicText": t([
                                            undefined
                                        ]),
                                        "exportValue": t([
                                            undefined
                                        ]),
                                        "header": t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Tru answers" }, "args": {} }
                                            })
                                        ]),
                                        "tooltip": t([
                                            undefined
                                        ]),
                                        "filter": [
                                            <$DatagridNumberFilter key="p.MyFirstModule.Home_Web.numberFilter2"
                                                $widgetId="p.MyFirstModule.Home_Web.numberFilter2"
                                                attrChoice={"auto"}
                                                linkedDs={undefined}
                                                attributes={[]}
                                                defaultValue={undefined}
                                                defaultFilter={"equal"}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                adjustable={true}
                                                delay={500}
                                                onChange={undefined}
                                                screenReaderButtonCaption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                screenReaderInputCaption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Search" }, "args": {} }
                                                    })
                                                ])}
                                                class={"mx-name-numberFilter2"}
                                                style={undefined}
                                                tabIndex={undefined} />
                                        ],
                                        "visible": ExpressionProperty({
                                            "expression": { "expr": { "type": "literal", "value": true }, "args": {} }
                                        }),
                                        "sortable": true,
                                        "resizable": true,
                                        "draggable": true,
                                        "hidable": "yes",
                                        "allowEventPropagation": true,
                                        "width": "autoFill",
                                        "minWidth": "auto",
                                        "minWidthLimit": 100,
                                        "size": 1,
                                        "alignment": "right",
                                        "wrapText": false
                                    },
                                    {
                                        "showContentAs": "attribute",
                                        "attribute": ListAttributeProperty({
                                            "path": "",
                                            "entity": "MyFirstModule.Quiz",
                                            "attribute": "FalseAnswers",
                                            "attributeType": "Integer",
                                            "sortable": true,
                                            "filterable": true,
                                            "dataSourceId": "p.0",
                                            "isList": false
                                        }),
                                        "content": undefined,
                                        "dynamicText": t([
                                            undefined
                                        ]),
                                        "exportValue": t([
                                            undefined
                                        ]),
                                        "header": t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "False answers" }, "args": {} }
                                            })
                                        ]),
                                        "tooltip": t([
                                            undefined
                                        ]),
                                        "filter": [
                                            <$DatagridNumberFilter key="p.MyFirstModule.Home_Web.numberFilter1"
                                                $widgetId="p.MyFirstModule.Home_Web.numberFilter1"
                                                attrChoice={"auto"}
                                                linkedDs={undefined}
                                                attributes={[]}
                                                defaultValue={undefined}
                                                defaultFilter={"equal"}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                adjustable={true}
                                                delay={500}
                                                onChange={undefined}
                                                screenReaderButtonCaption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                screenReaderInputCaption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Search" }, "args": {} }
                                                    })
                                                ])}
                                                class={"mx-name-numberFilter1"}
                                                style={undefined}
                                                tabIndex={undefined} />
                                        ],
                                        "visible": ExpressionProperty({
                                            "expression": { "expr": { "type": "literal", "value": true }, "args": {} }
                                        }),
                                        "sortable": true,
                                        "resizable": true,
                                        "draggable": true,
                                        "hidable": "yes",
                                        "allowEventPropagation": true,
                                        "width": "autoFill",
                                        "minWidth": "auto",
                                        "minWidthLimit": 100,
                                        "size": 1,
                                        "alignment": "right",
                                        "wrapText": false
                                    },
                                    {
                                        "showContentAs": "attribute",
                                        "attribute": ListAttributeProperty({
                                            "path": "",
                                            "entity": "MyFirstModule.Quiz",
                                            "attribute": "IsOpen",
                                            "attributeType": "Boolean",
                                            "sortable": true,
                                            "filterable": true,
                                            "dataSourceId": "p.0",
                                            "isList": false
                                        }),
                                        "content": undefined,
                                        "dynamicText": t([
                                            undefined
                                        ]),
                                        "exportValue": t([
                                            undefined
                                        ]),
                                        "header": t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Is open" }, "args": {} }
                                            })
                                        ]),
                                        "tooltip": t([
                                            undefined
                                        ]),
                                        "filter": [
                                            <$DatagridDropdownFilter key="p.MyFirstModule.Home_Web.drop_downFilter1"
                                                $widgetId="p.MyFirstModule.Home_Web.drop_downFilter1"
                                                baseType={"attr"}
                                                linkedDs={undefined}
                                                attrChoice={"auto"}
                                                auto={true}
                                                filterOptions={[]}
                                                refOptions={undefined}
                                                refCaptionSource={"attr"}
                                                fetchOptionsLazy={false}
                                                defaultValue={undefined}
                                                filterable={false}
                                                multiSelect={false}
                                                emptyOptionCaption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "None" }, "args": {} }
                                                    })
                                                ])}
                                                clearable={true}
                                                selectedItemsStyle={"text"}
                                                selectionMethod={"checkbox"}
                                                onChange={undefined}
                                                ariaLabel={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                emptySelectionCaption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Select" }, "args": {} }
                                                    })
                                                ])}
                                                filterInputPlaceholderCaption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Search" }, "args": {} }
                                                    })
                                                ])}
                                                class={"mx-name-drop_downFilter1"}
                                                style={undefined}
                                                tabIndex={undefined} />
                                        ],
                                        "visible": ExpressionProperty({
                                            "expression": { "expr": { "type": "literal", "value": true }, "args": {} }
                                        }),
                                        "sortable": true,
                                        "resizable": true,
                                        "draggable": true,
                                        "hidable": "yes",
                                        "allowEventPropagation": true,
                                        "width": "autoFill",
                                        "minWidth": "auto",
                                        "minWidthLimit": 100,
                                        "size": 1,
                                        "alignment": "left",
                                        "wrapText": false
                                    },
                                    {
                                        "showContentAs": "customContent",
                                        "attribute": ListAttributeProperty({
                                            "path": "",
                                            "entity": "MyFirstModule.Quiz",
                                            "attribute": "TrueAnswers",
                                            "attributeType": "Integer",
                                            "sortable": true,
                                            "filterable": true,
                                            "dataSourceId": "p.0",
                                            "isList": false
                                        }),
                                        "content": TemplatedWidgetProperty({
                                            "dataSourceId": "p.0",
                                            "editable": false,
                                            "children": () => [
                                                <$ConditionalVisibilityWrapper key="p.MyFirstModule.Home_Web.actionButton2$visibility"
                                                    $widgetId="p.MyFirstModule.Home_Web.actionButton2$visibility"
                                                    visible={ExpressionProperty({
                                                        "expression": { "expr": { "type": "function", "name": "_hasSomeRole", "parameters": [ { "type": "literal", "value": "User" } ] }, "args": {} }
                                                    })}
                                                    contents={[
                                                        <$ActionButton key="p.MyFirstModule.Home_Web.actionButton2"
                                                            $widgetId="p.MyFirstModule.Home_Web.actionButton2"
                                                            buttonId={"p.MyFirstModule.Home_Web.actionButton2"}
                                                            class={"mx-name-actionButton2 btn-lg"}
                                                            style={undefined}
                                                            tabIndex={undefined}
                                                            renderType={"link"}
                                                            role={"button"}
                                                            buttonClass={"btn-primary"}
                                                            caption={t([
                                                                ExpressionProperty({
                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                })
                                                            ])}
                                                            tooltip={TextProperty({
                                                                "value": t([
                                                                    ""
                                                                ])
                                                            })}
                                                            icon={WebIconProperty({
                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-pen-write-paper" }
                                                            })}
                                                            action={ActionProperty({
                                                                "action": { "type": "openPage", "argMap": { "param$Quiz": { "widget": "p.MyFirstModule.Home_Web.dataGrid2_1", "source": "object" } }, "config": { "name": "MyFirstModule/Quiz_NewEdit.page.xml", "location": "content", "allowedRoles": [ "Administrator", "User" ] }, "disabledDuringExecution": true },
                                                                "abortOnServerValidation": true
                                                            })} />
                                                    ]} />,
                                                <$ConditionalVisibilityWrapper key="p.MyFirstModule.Home_Web.actionButton4$visibility"
                                                    $widgetId="p.MyFirstModule.Home_Web.actionButton4$visibility"
                                                    visible={ExpressionProperty({
                                                        "expression": { "expr": { "type": "function", "name": "_hasSomeRole", "parameters": [ { "type": "literal", "value": "Administrator" } ] }, "args": {} }
                                                    })}
                                                    contents={[
                                                        <$ActionButton key="p.MyFirstModule.Home_Web.actionButton4"
                                                            $widgetId="p.MyFirstModule.Home_Web.actionButton4"
                                                            buttonId={"p.MyFirstModule.Home_Web.actionButton4"}
                                                            class={"mx-name-actionButton4 btn-lg"}
                                                            style={undefined}
                                                            tabIndex={undefined}
                                                            renderType={"link"}
                                                            role={"button"}
                                                            buttonClass={"btn-primary"}
                                                            caption={t([
                                                                ExpressionProperty({
                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                })
                                                            ])}
                                                            tooltip={TextProperty({
                                                                "value": t([
                                                                    ""
                                                                ])
                                                            })}
                                                            icon={WebIconProperty({
                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-pencil" }
                                                            })}
                                                            action={ActionProperty({
                                                                "action": { "type": "openPage", "argMap": { "param$Quiz": { "widget": "p.MyFirstModule.Home_Web.dataGrid2_1", "source": "object" } }, "config": { "name": "MyFirstModule/Quiz_NewEdit_Admin.page.xml", "location": "content", "allowedRoles": [ "Administrator", "User" ] }, "disabledDuringExecution": true },
                                                                "abortOnServerValidation": true
                                                            })} />
                                                    ]} />,
                                                <$ConditionalVisibilityWrapper key="p.MyFirstModule.Home_Web.actionButton3$visibility"
                                                    $widgetId="p.MyFirstModule.Home_Web.actionButton3$visibility"
                                                    visible={ExpressionProperty({
                                                        "expression": { "expr": { "type": "function", "name": "_hasSomeRole", "parameters": [ { "type": "literal", "value": "Administrator" }, { "type": "literal", "value": "User" } ] }, "args": {} }
                                                    })}
                                                    contents={[
                                                        <$ActionButton key="p.MyFirstModule.Home_Web.actionButton3"
                                                            $widgetId="p.MyFirstModule.Home_Web.actionButton3"
                                                            buttonId={"p.MyFirstModule.Home_Web.actionButton3"}
                                                            class={"mx-name-actionButton3 btn-lg"}
                                                            style={undefined}
                                                            tabIndex={undefined}
                                                            renderType={"link"}
                                                            role={"button"}
                                                            buttonClass={"btn-primary"}
                                                            caption={t([
                                                                ExpressionProperty({
                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                })
                                                            ])}
                                                            tooltip={TextProperty({
                                                                "value": t([
                                                                    ""
                                                                ])
                                                            })}
                                                            icon={WebIconProperty({
                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-trash-can" }
                                                            })}
                                                            action={ActionProperty({
                                                                "action": { "type": "deleteObject", "argMap": { "$object": { "widget": "p.MyFirstModule.Home_Web.dataGrid2_1", "source": "object" } }, "config": { "closePage": false, "operationId": "FHh8JWrDblCnpFqkQ/QrvA" }, "disabledDuringExecution": true },
                                                                "abortOnServerValidation": true
                                                            })} />
                                                    ]} />
                                            ]
                                        }),
                                        "dynamicText": t([
                                            undefined
                                        ]),
                                        "exportValue": t([
                                            undefined
                                        ]),
                                        "header": t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                            })
                                        ]),
                                        "tooltip": t([
                                            undefined
                                        ]),
                                        "filter": undefined,
                                        "visible": ExpressionProperty({
                                            "expression": { "expr": { "type": "literal", "value": true }, "args": {} }
                                        }),
                                        "sortable": false,
                                        "resizable": true,
                                        "draggable": true,
                                        "hidable": "no",
                                        "allowEventPropagation": true,
                                        "width": "autoFit",
                                        "minWidth": "auto",
                                        "minWidthLimit": 100,
                                        "size": 1,
                                        "alignment": "left",
                                        "wrapText": false
                                    }
                                ]}
                                columnsFilterable={true}
                                pageSize={20}
                                pagination={"buttons"}
                                showPagingButtons={"always"}
                                showNumberOfRows={false}
                                pagingPosition={"bottom"}
                                loadMoreButtonCaption={t([
                                    ExpressionProperty({
                                        "expression": { "expr": { "type": "literal", "value": "Load More" }, "args": {} }
                                    })
                                ])}
                                showEmptyPlaceholder={"none"}
                                emptyPlaceholder={undefined}
                                rowClass={undefined}
                                onClickTrigger={"double"}
                                onClick={undefined}
                                onSelectionChange={undefined}
                                filtersPlaceholder={[
                                    <$ConditionalVisibilityWrapper key="p.MyFirstModule.Home_Web.actionButton1$visibility"
                                        $widgetId="p.MyFirstModule.Home_Web.actionButton1$visibility"
                                        visible={ExpressionProperty({
                                            "expression": { "expr": { "type": "function", "name": "_hasSomeRole", "parameters": [ { "type": "literal", "value": "Administrator" }, { "type": "literal", "value": "User" } ] }, "args": {} }
                                        })}
                                        contents={[
                                            <$ActionButton key="p.MyFirstModule.Home_Web.actionButton1"
                                                $widgetId="p.MyFirstModule.Home_Web.actionButton1"
                                                buttonId={"p.MyFirstModule.Home_Web.actionButton1"}
                                                class={"mx-name-actionButton1"}
                                                style={undefined}
                                                tabIndex={undefined}
                                                renderType={"button"}
                                                role={undefined}
                                                buttonClass={"btn-primary"}
                                                caption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "New Quiz" }, "args": {} }
                                                    })
                                                ])}
                                                tooltip={TextProperty({
                                                    "value": t([
                                                        ""
                                                    ])
                                                })}
                                                icon={WebIconProperty({
                                                    "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-add" }
                                                })}
                                                action={ActionProperty({
                                                    "action": { "type": "callMicroflow", "argMap": {}, "config": { "operationId": "jZrbc+X4DFmzAHS7Zdf2Wg", "validate": "view", "allowedRoles": [ "Administrator", "User" ] }, "disabledDuringExecution": true },
                                                    "abortOnServerValidation": true
                                                })} />
                                        ]} />
                                ]}
                                columnsSortable={true}
                                columnsResizable={true}
                                columnsDraggable={true}
                                columnsHidable={true}
                                configurationStorageType={"attribute"}
                                storeFiltersInPersonalization={true}
                                filterSectionTitle={t([
                                    ExpressionProperty({
                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                    })
                                ])}
                                exportDialogLabel={t([
                                    ExpressionProperty({
                                        "expression": { "expr": { "type": "literal", "value": "Export progress" }, "args": {} }
                                    })
                                ])}
                                cancelExportLabel={t([
                                    ExpressionProperty({
                                        "expression": { "expr": { "type": "literal", "value": "Cancel data export" }, "args": {} }
                                    })
                                ])}
                                selectRowLabel={t([
                                    ExpressionProperty({
                                        "expression": { "expr": { "type": "literal", "value": "Select row" }, "args": {} }
                                    })
                                ])}
                                selectAllRowsLabel={t([
                                    ExpressionProperty({
                                        "expression": { "expr": { "type": "literal", "value": "Select all rows" }, "args": {} }
                                    })
                                ])}
                                selectedCountTemplateSingular={t([
                                    ExpressionProperty({
                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                    })
                                ])}
                                selectedCountTemplatePlural={t([
                                    ExpressionProperty({
                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                    })
                                ])}
                                class={"mx-name-dataGrid2_1"}
                                style={undefined}
                                tabIndex={undefined} />
                        ]} />
                ]} />
        ]} />,
    <$ConditionalVisibilityWrapper key="p.MyFirstModule.Home_Web.actionButton5$visibility"
        $widgetId="p.MyFirstModule.Home_Web.actionButton5$visibility"
        visible={ExpressionProperty({
            "expression": { "expr": { "type": "function", "name": "_isNamedUser", "parameters": [] }, "args": {} }
        })}
        contents={[
            <$ActionButton key="p.MyFirstModule.Home_Web.actionButton5"
                $widgetId="p.MyFirstModule.Home_Web.actionButton5"
                buttonId={"p.MyFirstModule.Home_Web.actionButton5"}
                class={"mx-name-actionButton5"}
                style={undefined}
                tabIndex={undefined}
                renderType={"button"}
                role={undefined}
                buttonClass={"btn-default"}
                caption={t([
                    ExpressionProperty({
                        "expression": { "expr": { "type": "literal", "value": "Sign out" }, "args": {} }
                    })
                ])}
                tooltip={TextProperty({
                    "value": t([
                        ""
                    ])
                })}
                icon={undefined}
                action={ActionProperty({
                    "action": { "type": "signOut", "argMap": {}, "config": { "namedUser": true }, "disabledDuringExecution": true },
                    "abortOnServerValidation": true
                })} />
        ]} />
]}</PageFragment>);

export const title = t([
    "Homepage"
]);

export const classes = "layout-atlas layout-atlas-responsive-topbar";

export const autofocus = "desktopOnly";
export const style = {};
export const content = { ...parentContent,
    "Atlas_Core.Atlas_TopBar.Main": region$Main,
};
