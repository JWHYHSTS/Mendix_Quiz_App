import { createElement } from "react";
const React = { createElement };

import { PageFragment } from "mendix/PageFragment";
import { ActionProperty } from "mendix/ActionProperty";
import { AssociationObjectListProperty } from "mendix/AssociationObjectListProperty";
import { AssociationObjectProperty } from "mendix/AssociationObjectProperty";
import { AttributeProperty } from "mendix/AttributeProperty";
import { DerivedUniqueIdProperty } from "mendix/DerivedUniqueIdProperty";
import { ExpressionProperty } from "mendix/ExpressionProperty";
import { FileUploadProperty } from "mendix/FileUploadProperty";
import { MicroflowObjectProperty } from "mendix/MicroflowObjectProperty";
import { TemplatedWidgetProperty } from "mendix/TemplatedWidgetProperty";
import { TextProperty } from "mendix/TextProperty";
import { ValidationProperty } from "mendix/ValidationProperty";
import { WebDynamicImageProperty } from "mendix/WebDynamicImageProperty";
import { WebIconProperty } from "mendix/WebIconProperty";

import { ActionButton } from "mendix/widgets/web/ActionButton";
import { CheckBox } from "mendix/widgets/web/CheckBox";
import { ConditionalVisibilityWrapper } from "mendix/widgets/web/ConditionalVisibilityWrapper";
import { DataView } from "mendix/widgets/web/DataView";
import { Div } from "mendix/widgets/web/Div";
import { FileManager } from "mendix/widgets/web/FileManager";
import { FormGroup } from "mendix/widgets/web/FormGroup";
import * as ImageWidgetModule from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/deployment/web/widgets/com/mendix/widget/web/image/Image.mjs";
const Image = Object.getOwnPropertyDescriptor(ImageWidgetModule, "Image")?.value || Object.getOwnPropertyDescriptor(ImageWidgetModule, "default")?.value;   
import "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/deployment/web/widgets/com/mendix/widget/web/image/Image.css";
import { ListView } from "mendix/widgets/web/ListView";
import { Text } from "mendix/widgets/web/Text";
import { TextBox } from "mendix/widgets/web/TextBox";
import { addEnumerations, asPluginWidgets, t } from "mendix";

import { content as parentContent } from "../layouts/Atlas_Core.PopupLayout.js";

const { $Div, $DataView, $FormGroup, $CheckBox, $TextBox, $FileManager, $ConditionalVisibilityWrapper, $ActionButton, $Image, $ListView, $Text } = asPluginWidgets({ Div, DataView, FormGroup, CheckBox, TextBox, FileManager, ConditionalVisibilityWrapper, ActionButton, Image, ListView, Text });

const region$Main = (historyId) => (<PageFragment renderKey={historyId}>{[
    <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid1"
        $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid1"
        class={"mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid container-fluid"}
        style={undefined}
        content={[
            <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid1$row0"
                $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid1$row0"
                class={"row"}
                style={undefined}
                content={[
                    <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid1$row0$column0"
                        $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid1$row0$column0"
                        class={"col-lg col-md col"}
                        style={undefined}
                        content={[
                            <$DataView key="p.MyFirstModule.Quetions_NewEdit.dataView1"
                                $widgetId="p.MyFirstModule.Quetions_NewEdit.dataView1"
                                class={"mx-name-dataView1 form-vertical"}
                                style={undefined}
                                tabIndex={undefined}
                                object={AssociationObjectProperty({
                                    "dataSourceId": "p.17",
                                    "scope": "$Quetions",
                                    "editable": true
                                })}
                                emptyMessage={TextProperty({
                                    "value": t([
                                        ""
                                    ])
                                })}
                                body={[
                                    <$FormGroup key="p.MyFirstModule.Quetions_NewEdit.checkBox1$formGroup"
                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.checkBox1$formGroup"
                                        class={"mx-name-checkBox1 mx-checkbox label-after"}
                                        style={undefined}
                                        control={[
                                            <$CheckBox key="p.MyFirstModule.Quetions_NewEdit.checkBox1"
                                                $widgetId="p.MyFirstModule.Quetions_NewEdit.checkBox1"
                                                value={AttributeProperty({
                                                    "scope": "p.MyFirstModule.Quetions_NewEdit.dataView1",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Quetions",
                                                    "attribute": "IsActive",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null
                                                })}
                                                readOnlyStyle={"control"}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                caption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Is active" }, "args": {} }
                                                    })
                                                ])}
                                                ariaLabel={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p.MyFirstModule.Quetions_NewEdit.checkBox1"
                                                })} />
                                        ]}
                                        caption={undefined}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p.MyFirstModule.Quetions_NewEdit.checkBox1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p.MyFirstModule.Quetions_NewEdit.checkBox1"
                                        })} />,
                                    <$FormGroup key="p.MyFirstModule.Quetions_NewEdit.textBox1$formGroup"
                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.textBox1$formGroup"
                                        class={"mx-name-textBox1 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p.MyFirstModule.Quetions_NewEdit.textBox1"
                                                $widgetId="p.MyFirstModule.Quetions_NewEdit.textBox1"
                                                inputValue={AttributeProperty({
                                                    "scope": "p.MyFirstModule.Quetions_NewEdit.dataView1",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Quetions",
                                                    "attribute": "Question",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={undefined}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p.MyFirstModule.Quetions_NewEdit.textBox1"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Question" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p.MyFirstModule.Quetions_NewEdit.textBox1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p.MyFirstModule.Quetions_NewEdit.textBox1"
                                        })} />,
                                    <$DataView key="p.MyFirstModule.Quetions_NewEdit.dataView2"
                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.dataView2"
                                        class={"mx-name-dataView2 form-vertical"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        object={MicroflowObjectProperty({
                                            "dataSourceId": "p.26",
                                            "scope": "p.MyFirstModule.Quetions_NewEdit.dataView1",
                                            "editable": true,
                                            "operationId": "7lkVNSUy4lSn7aqbj5iIkQ",
                                            "argMap": { "Quetions": { "widget": "$Quetions", "source": "object" } }
                                        })}
                                        emptyMessage={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        body={[
                                            <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid2"
                                                $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid2"
                                                class={"mx-name-layoutGrid2 mx-layoutgrid mx-layoutgrid-fluid"}
                                                style={undefined}
                                                content={[
                                                    <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid2$row0"
                                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid2$row0"
                                                        class={"row"}
                                                        style={undefined}
                                                        content={[
                                                            <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid2$row0$column0"
                                                                $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid2$row0$column0"
                                                                class={"col-lg-6 col-md col"}
                                                                style={undefined}
                                                                content={[
                                                                    <$FormGroup key="p.MyFirstModule.Quetions_NewEdit.imageUploader1$formGroup"
                                                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.imageUploader1$formGroup"
                                                                        class={"mx-imageuploader mx-name-imageUploader1 mx-imageuploader"}
                                                                        style={undefined}
                                                                        control={[
                                                                            <$FileManager key="p.MyFirstModule.Quetions_NewEdit.imageUploader1"
                                                                                $widgetId="p.MyFirstModule.Quetions_NewEdit.imageUploader1"
                                                                                upload={FileUploadProperty({
                                                                                    "scope": "p.MyFirstModule.Quetions_NewEdit.dataView2",
                                                                                    "thumbnailSize": {
                                                                                        "width": 100,
                                                                                        "height": 75
                                                                                    }
                                                                                })}
                                                                                maxFileSize={5}
                                                                                extensions={""}
                                                                                tabIndex={undefined}
                                                                                id={DerivedUniqueIdProperty({
                                                                                    "widgetId": "p.MyFirstModule.Quetions_NewEdit.imageUploader1"
                                                                                })} />
                                                                        ]}
                                                                        caption={t([
                                                                            ExpressionProperty({
                                                                                "expression": { "expr": { "type": "literal", "value": "Upload image" }, "args": {} }
                                                                            })
                                                                        ])}
                                                                        labelFor={DerivedUniqueIdProperty({
                                                                            "widgetId": "p.MyFirstModule.Quetions_NewEdit.imageUploader1"
                                                                        })}
                                                                        width={undefined}
                                                                        orientation={"vertical"}
                                                                        hasError={ValidationProperty({
                                                                            "inputWidgetId": "p.MyFirstModule.Quetions_NewEdit.imageUploader1"
                                                                        })} />
                                                                ]} />,
                                                            <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid2$row0$column1"
                                                                $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid2$row0$column1"
                                                                class={"col-lg-2 col-md col align-self-center"}
                                                                style={undefined}
                                                                content={[
                                                                    <$ConditionalVisibilityWrapper key="p.MyFirstModule.Quetions_NewEdit.actionButton3$visibility"
                                                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.actionButton3$visibility"
                                                                        visible={ExpressionProperty({
                                                                            "expression": { "expr": { "type": "function", "name": "_hasSomeRole", "parameters": [ { "type": "literal", "value": "Administrator" } ] }, "args": {} }
                                                                        })}
                                                                        contents={[
                                                                            <$ActionButton key="p.MyFirstModule.Quetions_NewEdit.actionButton3"
                                                                                $widgetId="p.MyFirstModule.Quetions_NewEdit.actionButton3"
                                                                                buttonId={"p.MyFirstModule.Quetions_NewEdit.actionButton3"}
                                                                                class={"mx-name-actionButton3"}
                                                                                style={undefined}
                                                                                tabIndex={undefined}
                                                                                renderType={"button"}
                                                                                role={undefined}
                                                                                buttonClass={"btn-default"}
                                                                                caption={t([
                                                                                    ExpressionProperty({
                                                                                        "expression": { "expr": { "type": "literal", "value": "Upload" }, "args": {} }
                                                                                    })
                                                                                ])}
                                                                                tooltip={TextProperty({
                                                                                    "value": t([
                                                                                        ""
                                                                                    ])
                                                                                })}
                                                                                icon={undefined}
                                                                                action={ActionProperty({
                                                                                    "action": { "type": "callMicroflow", "argMap": { "ImageQuestion": { "widget": "p.MyFirstModule.Quetions_NewEdit.dataView2", "source": "object" } }, "config": { "operationId": "bu4cSjx7TVeSiXDJlv+jgA", "validate": "view", "allowedRoles": [ "Administrator" ] }, "disabledDuringExecution": true },
                                                                                    "abortOnServerValidation": true
                                                                                })} />
                                                                        ]} />
                                                                ]} />
                                                        ]} />
                                                ]} />,
                                            <$Image key="p.MyFirstModule.Quetions_NewEdit.image1"
                                                $widgetId="p.MyFirstModule.Quetions_NewEdit.image1"
                                                datasource={"image"}
                                                imageObject={WebDynamicImageProperty({
                                                    "scope": "p.MyFirstModule.Quetions_NewEdit.dataView2",
                                                    "showAsThumbnail": false,
                                                    "shareObject": false
                                                })}
                                                defaultImageDynamic={undefined}
                                                imageUrl={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                imageIcon={undefined}
                                                isBackgroundImage={false}
                                                children={undefined}
                                                onClickType={"action"}
                                                onClick={undefined}
                                                alternativeText={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                widthUnit={"percentage"}
                                                width={50}
                                                heightUnit={"auto"}
                                                height={100}
                                                iconSize={14}
                                                displayAs={"fullImage"}
                                                responsive={true}
                                                class={"mx-name-image1"}
                                                style={undefined}
                                                tabIndex={undefined} />
                                        ]}
                                        hideFooter={false}
                                        footer={undefined} />,
                                    <$ConditionalVisibilityWrapper key="p.MyFirstModule.Quetions_NewEdit.actionButton4$visibility"
                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.actionButton4$visibility"
                                        visible={ExpressionProperty({
                                            "expression": { "expr": { "type": "function", "name": "_hasSomeRole", "parameters": [ { "type": "literal", "value": "Administrator" } ] }, "args": {} }
                                        })}
                                        contents={[
                                            <$ActionButton key="p.MyFirstModule.Quetions_NewEdit.actionButton4"
                                                $widgetId="p.MyFirstModule.Quetions_NewEdit.actionButton4"
                                                buttonId={"p.MyFirstModule.Quetions_NewEdit.actionButton4"}
                                                class={"mx-name-actionButton4"}
                                                style={undefined}
                                                tabIndex={undefined}
                                                renderType={"button"}
                                                role={undefined}
                                                buttonClass={"btn-primary"}
                                                caption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Add Answer" }, "args": {} }
                                                    })
                                                ])}
                                                tooltip={TextProperty({
                                                    "value": t([
                                                        ""
                                                    ])
                                                })}
                                                icon={WebIconProperty({
                                                    "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-add" }
                                                })}
                                                action={ActionProperty({
                                                    "action": { "type": "callMicroflow", "argMap": { "Quetions": { "widget": "$Quetions", "source": "object" } }, "config": { "operationId": "8P+uq/2NVVqxP/D+4QdddQ", "validate": "view", "allowedRoles": [ "Administrator" ] }, "disabledDuringExecution": true },
                                                    "abortOnServerValidation": true
                                                })} />
                                        ]} />,
                                    <$ListView key="p.MyFirstModule.Quetions_NewEdit.listView1"
                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.listView1"
                                        class={"mx-name-listView1"}
                                        style={undefined}
                                        listValue={AssociationObjectListProperty({
                                            "dataSourceId": "p.4",
                                            "entity": "MyFirstModule.Answers",
                                            "scope": "$Quetions",
                                            "operationId": "iyWU1RZVqVGn1bQyBgeXFA"
                                        })}
                                        itemTemplate={TemplatedWidgetProperty({
                                            "dataSourceId": "p.4",
                                            "editable": true,
                                            "children": () => [
                                                <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid3"
                                                    $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid3"
                                                    class={"mx-name-layoutGrid3 mx-layoutgrid mx-layoutgrid-fluid"}
                                                    style={undefined}
                                                    content={[
                                                        <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid3$row0"
                                                            $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid3$row0"
                                                            class={"row"}
                                                            style={undefined}
                                                            content={[
                                                                <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid3$row0$column0"
                                                                    $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid3$row0$column0"
                                                                    class={"col-lg-1 col-md col"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$FormGroup key="p.MyFirstModule.Quetions_NewEdit.checkBox2$formGroup"
                                                                            $widgetId="p.MyFirstModule.Quetions_NewEdit.checkBox2$formGroup"
                                                                            class={"mx-name-checkBox2 mx-checkbox label-after"}
                                                                            style={undefined}
                                                                            control={[
                                                                                <$CheckBox key="p.MyFirstModule.Quetions_NewEdit.checkBox2"
                                                                                    $widgetId="p.MyFirstModule.Quetions_NewEdit.checkBox2"
                                                                                    value={AttributeProperty({
                                                                                        "scope": "p.MyFirstModule.Quetions_NewEdit.listView1",
                                                                                        "path": "",
                                                                                        "entity": "MyFirstModule.Answers",
                                                                                        "attribute": "IsTrue",
                                                                                        "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                                                        "isList": false,
                                                                                        "validation": null
                                                                                    })}
                                                                                    readOnlyStyle={"control"}
                                                                                    onEnter={undefined}
                                                                                    onLeave={undefined}
                                                                                    caption={undefined}
                                                                                    ariaLabel={t([
                                                                                        ExpressionProperty({
                                                                                            "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                        })
                                                                                    ])}
                                                                                    tabIndex={undefined}
                                                                                    id={DerivedUniqueIdProperty({
                                                                                        "widgetId": "p.MyFirstModule.Quetions_NewEdit.checkBox2"
                                                                                    })} />
                                                                            ]}
                                                                            caption={undefined}
                                                                            labelFor={DerivedUniqueIdProperty({
                                                                                "widgetId": "p.MyFirstModule.Quetions_NewEdit.checkBox2"
                                                                            })}
                                                                            width={undefined}
                                                                            orientation={"vertical"}
                                                                            hasError={ValidationProperty({
                                                                                "inputWidgetId": "p.MyFirstModule.Quetions_NewEdit.checkBox2"
                                                                            })} />
                                                                    ]} />,
                                                                <$Div key="p.MyFirstModule.Quetions_NewEdit.layoutGrid3$row0$column1"
                                                                    $widgetId="p.MyFirstModule.Quetions_NewEdit.layoutGrid3$row0$column1"
                                                                    class={"col-lg col-md col align-self-center"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$Text key="p.MyFirstModule.Quetions_NewEdit.text1"
                                                                            $widgetId="p.MyFirstModule.Quetions_NewEdit.text1"
                                                                            class={"mx-name-text1"}
                                                                            style={undefined}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "variable", "variable": "currentObject", "path": "Answer" }, "args": { "currentObject": { "widget": "p.MyFirstModule.Quetions_NewEdit.listView1", "source": "object" } } }
                                                                                })
                                                                            ])}
                                                                            renderMode={"span"} />,
                                                                        <$Image key="p.MyFirstModule.Quetions_NewEdit.image2"
                                                                            $widgetId="p.MyFirstModule.Quetions_NewEdit.image2"
                                                                            datasource={"image"}
                                                                            imageObject={WebDynamicImageProperty({
                                                                                "scope": "p.MyFirstModule.Quetions_NewEdit.listView1",
                                                                                "showAsThumbnail": false,
                                                                                "shareObject": false,
                                                                                "path": "MyFirstModule.Answers_ImageQuestion/MyFirstModule.ImageQuestion"
                                                                            })}
                                                                            defaultImageDynamic={undefined}
                                                                            imageUrl={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                })
                                                                            ])}
                                                                            imageIcon={undefined}
                                                                            isBackgroundImage={false}
                                                                            children={undefined}
                                                                            onClickType={"action"}
                                                                            onClick={undefined}
                                                                            alternativeText={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                })
                                                                            ])}
                                                                            widthUnit={"percentage"}
                                                                            width={25}
                                                                            heightUnit={"pixels"}
                                                                            height={25}
                                                                            iconSize={14}
                                                                            displayAs={"fullImage"}
                                                                            responsive={true}
                                                                            class={"mx-name-image2"}
                                                                            style={undefined}
                                                                            tabIndex={undefined} />
                                                                    ]} />
                                                            ]} />
                                                    ]} />
                                            ]
                                        })}
                                        onClick={undefined}
                                        pageSize={0} />
                                ]}
                                hideFooter={false}
                                footer={[
                                    <$ActionButton key="p.MyFirstModule.Quetions_NewEdit.actionButton1"
                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.actionButton1"
                                        buttonId={"p.MyFirstModule.Quetions_NewEdit.actionButton1"}
                                        class={"mx-name-actionButton1"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-success"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Save" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "saveChanges", "argMap": { "$object": { "widget": "p.MyFirstModule.Quetions_NewEdit.dataView1", "source": "object" } }, "config": { "operationId": "0gX9I5CnD1eFQqxF9IcAUQ", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />,
                                    <$ActionButton key="p.MyFirstModule.Quetions_NewEdit.actionButton2"
                                        $widgetId="p.MyFirstModule.Quetions_NewEdit.actionButton2"
                                        buttonId={"p.MyFirstModule.Quetions_NewEdit.actionButton2"}
                                        class={"mx-name-actionButton2"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-default"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Cancel" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "cancelChanges", "argMap": {}, "config": { "operationId": "w4Bj+mmz9lyxuZATXWPxRA", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />
                                ]} />
                        ]} />
                ]} />
        ]} />
]}</PageFragment>);

export const title = t([
    "Edit Quetions"
]);

export const classes = "";

export const autofocus = "off";
export const cancelChangesOperationId = "Kdi2fGsBG1G/yAokJUGhIg";
export const style = {};
export const content = { ...parentContent,
    "Atlas_Core.PopupLayout.Main": region$Main,
};
