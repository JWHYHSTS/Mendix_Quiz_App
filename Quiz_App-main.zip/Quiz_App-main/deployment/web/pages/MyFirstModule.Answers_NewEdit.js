import { createElement } from "react";
const React = { createElement };

import { PageFragment } from "mendix/PageFragment";
import { ActionProperty } from "mendix/ActionProperty";
import { AssociationObjectProperty } from "mendix/AssociationObjectProperty";
import { AttributeProperty } from "mendix/AttributeProperty";
import { DerivedUniqueIdProperty } from "mendix/DerivedUniqueIdProperty";
import { ExpressionProperty } from "mendix/ExpressionProperty";
import { FileUploadProperty } from "mendix/FileUploadProperty";
import { MicroflowObjectProperty } from "mendix/MicroflowObjectProperty";
import { TextProperty } from "mendix/TextProperty";
import { ValidationProperty } from "mendix/ValidationProperty";
import { WebDynamicImageProperty } from "mendix/WebDynamicImageProperty";

import { ActionButton } from "mendix/widgets/web/ActionButton";
import { CheckBox } from "mendix/widgets/web/CheckBox";
import { ConditionalVisibilityWrapper } from "mendix/widgets/web/ConditionalVisibilityWrapper";
import { DataView } from "mendix/widgets/web/DataView";
import { Div } from "mendix/widgets/web/Div";
import { FileManager } from "mendix/widgets/web/FileManager";
import { FormGroup } from "mendix/widgets/web/FormGroup";
import * as ImageWidgetModule from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/deployment/web/widgets/com/mendix/widget/web/image/Image.mjs";
const Image = Object.getOwnPropertyDescriptor(ImageWidgetModule, "Image")?.value || Object.getOwnPropertyDescriptor(ImageWidgetModule, "default")?.value;   
import "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/deployment/web/widgets/com/mendix/widget/web/image/Image.css";
import { TextBox } from "mendix/widgets/web/TextBox";
import { addEnumerations, asPluginWidgets, t } from "mendix";

import { content as parentContent } from "../layouts/Atlas_Core.PopupLayout.js";

const { $Div, $DataView, $FormGroup, $CheckBox, $TextBox, $FileManager, $ConditionalVisibilityWrapper, $ActionButton, $Image } = asPluginWidgets({ Div, DataView, FormGroup, CheckBox, TextBox, FileManager, ConditionalVisibilityWrapper, ActionButton, Image });

const region$Main = (historyId) => (<PageFragment renderKey={historyId}>{[
    <$Div key="p.MyFirstModule.Answers_NewEdit.layoutGrid1"
        $widgetId="p.MyFirstModule.Answers_NewEdit.layoutGrid1"
        class={"mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid container-fluid"}
        style={undefined}
        content={[
            <$Div key="p.MyFirstModule.Answers_NewEdit.layoutGrid1$row0"
                $widgetId="p.MyFirstModule.Answers_NewEdit.layoutGrid1$row0"
                class={"row"}
                style={undefined}
                content={[
                    <$Div key="p.MyFirstModule.Answers_NewEdit.layoutGrid1$row0$column0"
                        $widgetId="p.MyFirstModule.Answers_NewEdit.layoutGrid1$row0$column0"
                        class={"col-lg col-md col"}
                        style={undefined}
                        content={[
                            <$DataView key="p.MyFirstModule.Answers_NewEdit.dataView1"
                                $widgetId="p.MyFirstModule.Answers_NewEdit.dataView1"
                                class={"mx-name-dataView1 form-vertical"}
                                style={undefined}
                                tabIndex={undefined}
                                object={AssociationObjectProperty({
                                    "dataSourceId": "p.14",
                                    "scope": "$Answers",
                                    "editable": true
                                })}
                                emptyMessage={TextProperty({
                                    "value": t([
                                        ""
                                    ])
                                })}
                                body={[
                                    <$FormGroup key="p.MyFirstModule.Answers_NewEdit.checkBox1$formGroup"
                                        $widgetId="p.MyFirstModule.Answers_NewEdit.checkBox1$formGroup"
                                        class={"mx-name-checkBox1 mx-checkbox label-after"}
                                        style={undefined}
                                        control={[
                                            <$CheckBox key="p.MyFirstModule.Answers_NewEdit.checkBox1"
                                                $widgetId="p.MyFirstModule.Answers_NewEdit.checkBox1"
                                                value={AttributeProperty({
                                                    "scope": "p.MyFirstModule.Answers_NewEdit.dataView1",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Answers",
                                                    "attribute": "IsTrue",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null
                                                })}
                                                readOnlyStyle={"control"}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                caption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Is true" }, "args": {} }
                                                    })
                                                ])}
                                                ariaLabel={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p.MyFirstModule.Answers_NewEdit.checkBox1"
                                                })} />
                                        ]}
                                        caption={undefined}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p.MyFirstModule.Answers_NewEdit.checkBox1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p.MyFirstModule.Answers_NewEdit.checkBox1"
                                        })} />,
                                    <$FormGroup key="p.MyFirstModule.Answers_NewEdit.textBox1$formGroup"
                                        $widgetId="p.MyFirstModule.Answers_NewEdit.textBox1$formGroup"
                                        class={"mx-name-textBox1 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p.MyFirstModule.Answers_NewEdit.textBox1"
                                                $widgetId="p.MyFirstModule.Answers_NewEdit.textBox1"
                                                inputValue={AttributeProperty({
                                                    "scope": "p.MyFirstModule.Answers_NewEdit.dataView1",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Answers",
                                                    "attribute": "Answer",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={undefined}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p.MyFirstModule.Answers_NewEdit.textBox1"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Answer" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p.MyFirstModule.Answers_NewEdit.textBox1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p.MyFirstModule.Answers_NewEdit.textBox1"
                                        })} />,
                                    <$DataView key="p.MyFirstModule.Answers_NewEdit.dataView2"
                                        $widgetId="p.MyFirstModule.Answers_NewEdit.dataView2"
                                        class={"mx-name-dataView2 form-vertical"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        object={MicroflowObjectProperty({
                                            "dataSourceId": "p.23",
                                            "scope": "p.MyFirstModule.Answers_NewEdit.dataView1",
                                            "editable": true,
                                            "operationId": "+yuFctREml6KrU7zxzqveQ",
                                            "argMap": { "Answers": { "widget": "$Answers", "source": "object" } }
                                        })}
                                        emptyMessage={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        body={[
                                            <$Div key="p.MyFirstModule.Answers_NewEdit.layoutGrid2"
                                                $widgetId="p.MyFirstModule.Answers_NewEdit.layoutGrid2"
                                                class={"mx-name-layoutGrid2 mx-layoutgrid mx-layoutgrid-fluid"}
                                                style={undefined}
                                                content={[
                                                    <$Div key="p.MyFirstModule.Answers_NewEdit.layoutGrid2$row0"
                                                        $widgetId="p.MyFirstModule.Answers_NewEdit.layoutGrid2$row0"
                                                        class={"row"}
                                                        style={undefined}
                                                        content={[
                                                            <$Div key="p.MyFirstModule.Answers_NewEdit.layoutGrid2$row0$column0"
                                                                $widgetId="p.MyFirstModule.Answers_NewEdit.layoutGrid2$row0$column0"
                                                                class={"col-lg-6 col-md col"}
                                                                style={undefined}
                                                                content={[
                                                                    <$FormGroup key="p.MyFirstModule.Answers_NewEdit.imageUploader1$formGroup"
                                                                        $widgetId="p.MyFirstModule.Answers_NewEdit.imageUploader1$formGroup"
                                                                        class={"mx-imageuploader mx-name-imageUploader1 mx-imageuploader"}
                                                                        style={undefined}
                                                                        control={[
                                                                            <$FileManager key="p.MyFirstModule.Answers_NewEdit.imageUploader1"
                                                                                $widgetId="p.MyFirstModule.Answers_NewEdit.imageUploader1"
                                                                                upload={FileUploadProperty({
                                                                                    "scope": "p.MyFirstModule.Answers_NewEdit.dataView2",
                                                                                    "thumbnailSize": {
                                                                                        "width": 100,
                                                                                        "height": 75
                                                                                    }
                                                                                })}
                                                                                maxFileSize={5}
                                                                                extensions={""}
                                                                                tabIndex={undefined}
                                                                                id={DerivedUniqueIdProperty({
                                                                                    "widgetId": "p.MyFirstModule.Answers_NewEdit.imageUploader1"
                                                                                })} />
                                                                        ]}
                                                                        caption={t([
                                                                            ExpressionProperty({
                                                                                "expression": { "expr": { "type": "literal", "value": "Upload image" }, "args": {} }
                                                                            })
                                                                        ])}
                                                                        labelFor={DerivedUniqueIdProperty({
                                                                            "widgetId": "p.MyFirstModule.Answers_NewEdit.imageUploader1"
                                                                        })}
                                                                        width={undefined}
                                                                        orientation={"vertical"}
                                                                        hasError={ValidationProperty({
                                                                            "inputWidgetId": "p.MyFirstModule.Answers_NewEdit.imageUploader1"
                                                                        })} />
                                                                ]} />,
                                                            <$Div key="p.MyFirstModule.Answers_NewEdit.layoutGrid2$row0$column1"
                                                                $widgetId="p.MyFirstModule.Answers_NewEdit.layoutGrid2$row0$column1"
                                                                class={"col-lg-2 col-md col align-self-center"}
                                                                style={undefined}
                                                                content={[
                                                                    <$ConditionalVisibilityWrapper key="p.MyFirstModule.Answers_NewEdit.actionButton3$visibility"
                                                                        $widgetId="p.MyFirstModule.Answers_NewEdit.actionButton3$visibility"
                                                                        visible={ExpressionProperty({
                                                                            "expression": { "expr": { "type": "function", "name": "_hasSomeRole", "parameters": [ { "type": "literal", "value": "Administrator" } ] }, "args": {} }
                                                                        })}
                                                                        contents={[
                                                                            <$ActionButton key="p.MyFirstModule.Answers_NewEdit.actionButton3"
                                                                                $widgetId="p.MyFirstModule.Answers_NewEdit.actionButton3"
                                                                                buttonId={"p.MyFirstModule.Answers_NewEdit.actionButton3"}
                                                                                class={"mx-name-actionButton3"}
                                                                                style={undefined}
                                                                                tabIndex={undefined}
                                                                                renderType={"button"}
                                                                                role={undefined}
                                                                                buttonClass={"btn-default"}
                                                                                caption={t([
                                                                                    ExpressionProperty({
                                                                                        "expression": { "expr": { "type": "literal", "value": "Upload" }, "args": {} }
                                                                                    })
                                                                                ])}
                                                                                tooltip={TextProperty({
                                                                                    "value": t([
                                                                                        ""
                                                                                    ])
                                                                                })}
                                                                                icon={undefined}
                                                                                action={ActionProperty({
                                                                                    "action": { "type": "callMicroflow", "argMap": { "ImageQuestion": { "widget": "p.MyFirstModule.Answers_NewEdit.dataView2", "source": "object" } }, "config": { "operationId": "bu4cSjx7TVeSiXDJlv+jgA", "validate": "view", "allowedRoles": [ "Administrator" ] }, "disabledDuringExecution": true },
                                                                                    "abortOnServerValidation": true
                                                                                })} />
                                                                        ]} />
                                                                ]} />
                                                        ]} />
                                                ]} />,
                                            <$Image key="p.MyFirstModule.Answers_NewEdit.image1"
                                                $widgetId="p.MyFirstModule.Answers_NewEdit.image1"
                                                datasource={"image"}
                                                imageObject={WebDynamicImageProperty({
                                                    "scope": "p.MyFirstModule.Answers_NewEdit.dataView2",
                                                    "showAsThumbnail": false,
                                                    "shareObject": false
                                                })}
                                                defaultImageDynamic={undefined}
                                                imageUrl={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                imageIcon={undefined}
                                                isBackgroundImage={false}
                                                children={undefined}
                                                onClickType={"action"}
                                                onClick={undefined}
                                                alternativeText={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                widthUnit={"auto"}
                                                width={100}
                                                heightUnit={"auto"}
                                                height={100}
                                                iconSize={14}
                                                displayAs={"fullImage"}
                                                responsive={true}
                                                class={"mx-name-image1"}
                                                style={undefined}
                                                tabIndex={undefined} />
                                        ]}
                                        hideFooter={false}
                                        footer={undefined} />
                                ]}
                                hideFooter={false}
                                footer={[
                                    <$ActionButton key="p.MyFirstModule.Answers_NewEdit.actionButton1"
                                        $widgetId="p.MyFirstModule.Answers_NewEdit.actionButton1"
                                        buttonId={"p.MyFirstModule.Answers_NewEdit.actionButton1"}
                                        class={"mx-name-actionButton1"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-success"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Save" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "saveChanges", "argMap": { "$object": { "widget": "p.MyFirstModule.Answers_NewEdit.dataView1", "source": "object" } }, "config": { "operationId": "s5anYIV2slaLGEg1bFDoUA", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />,
                                    <$ActionButton key="p.MyFirstModule.Answers_NewEdit.actionButton2"
                                        $widgetId="p.MyFirstModule.Answers_NewEdit.actionButton2"
                                        buttonId={"p.MyFirstModule.Answers_NewEdit.actionButton2"}
                                        class={"mx-name-actionButton2"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-default"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Cancel" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "cancelChanges", "argMap": {}, "config": { "operationId": "UdhqWPlyX12pki2Z3a4Z+g", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />
                                ]} />
                        ]} />
                ]} />
        ]} />
]}</PageFragment>);

export const title = t([
    "Edit Answers"
]);

export const classes = "";

export const autofocus = "off";
export const cancelChangesOperationId = "RmZrmL1HNliYrLhGfkNSsA";
export const style = {};
export const content = { ...parentContent,
    "Atlas_Core.PopupLayout.Main": region$Main,
};
