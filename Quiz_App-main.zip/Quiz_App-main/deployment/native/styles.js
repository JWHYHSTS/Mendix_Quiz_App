import * as style0 from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/themesource/administration/native/main";
import * as style1 from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/themesource/fileuploader/native/main";
import * as style2 from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/themesource/nanoflowcommons/native/main";
import * as style3 from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/themesource/atlas_core/native/main";
import * as style4 from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/themesource/feedbackmodule/native/main";
import * as style5 from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/themesource/myfirstmodule/native/main";
import * as style6 from "D:/TAILIEUDAIHOC/NCKH/Mendix/Quiz_App-main/theme/native/main";

import { flatten } from "mendix/native";

module.exports = flatten([style0, style1, style2, style3, style4, style5, style6]);
