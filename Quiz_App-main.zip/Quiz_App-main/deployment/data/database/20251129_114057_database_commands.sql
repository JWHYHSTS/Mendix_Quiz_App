UPDATE "mendixsystem$attribute" SET "entity_id" = 'c1eb53ab-a193-47d7-ba41-8fb16f63f356', "attribute_name" = 'IsActive', "column_name" = 'isactive', "type" = 10, "length" = 0, "default_value" = 'true', "is_auto_number" = false WHERE "id" = 'b29e3345-418d-46ad-bd23-b019e1d6fa1b';
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20251129 11:40:57';
