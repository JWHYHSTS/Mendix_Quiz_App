export const lineChartSquare = {
    chart: {
        aspectRatio: 1
    }
};
export const lineChartMaxSpace = {
    chart: {
        flex: 1,
        aspectRatio: undefined
    }
};
